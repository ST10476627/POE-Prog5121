/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template;

/**
 *
 * @author RC_Student_lab
 */

package com.mycompany.main_msg_p2;

import javax.swing.*;
import java.util.UUID;

public class Message {
    public String recipient;
    public String message;
    public String messageId;
    public String messageHash;

    public Message(String recipient, String message, int count) {
        this.recipient = recipient;
        this.message = message;
        this.messageId = generateMessageId(count);
        this.messageHash = generateHash();
    }

    private String generateMessageId(int count) {
        return "MSG" + (count + 1);
    }

    private String generateHash() {
        return UUID.randomUUID().toString();
    }

    public boolean checkRecipientCell() {
        return recipient.matches("^\\+\\d{10,15}$");
    }

    public void sentMessage() {
        JOptionPane.showMessageDialog(null, "Message sent to " + recipient);
    }

    public String getMessageDetails() {
        return "Message ID: " + messageId +
                "\nRecipient: " + recipient +
                "\nMessage: " + message +
                "\nHash: " + messageHash;
    }
}
